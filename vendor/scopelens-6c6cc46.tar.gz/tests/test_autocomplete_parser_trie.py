"""State-only trie preserves parsing/recovery while retaining no syntax trees."""
import unittest
from unittest.mock import patch

from lark import Token
from lark.parsers import lalr_parser_state
from lark.parsers.lalr_interactive_parser import InteractiveParser
from scopelens.autocomplete import AutoCompleter, _ParserTrieCursor


class StateOnlyTrieTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.completer = AutoCompleter()

    def setUp(self):
        self.completer.reset_incremental()

    def test_lr_state_and_recovery_match_tree_building_parser(self):
        ac = self.completer
        terms = ac._lex_available("def f(x):\n    return x + y\n")
        ac._advance_stable([])
        root = ac._parser_trie_root
        for sequence in (terms, [t for t in terms if t.type != "_INDENT"],
                         [Token("_DEDENT", "")] + terms, terms[:3] + [Token("RPAR", ")")]):
            cursor = _ParserTrieCursor(root)
            clean = ac.lark.parse_interactive("")
            self.assertTrue(clean.parser_state.parse_conf.callbacks)
            for token in sequence:
                expected = ac._feed_one_available(token, clean)
                actual = ac._feed_one_available(token, cursor)
                self.assertEqual([(t.type,t.value) for t in actual],
                                 [(t.type,t.value) for t in expected])
                self.assertEqual(cursor.parser.parser_state.state_stack, clean.parser_state.state_stack)
                self.assertEqual(cursor.parser.parser_state.value_stack, [])
            with patch.object(InteractiveParser, "copy", side_effect=AssertionError("cached copy")), \
                 patch.object(InteractiveParser, "feed_token", side_effect=AssertionError("cached feed")):
                cursor = _ParserTrieCursor(root)
                for token in sequence:
                    ac._feed_one_available(token, cursor)

    def test_completion_does_not_deepcopy_or_retain_tree_values(self):
        ac = self.completer
        with patch.object(lalr_parser_state, "deepcopy", side_effect=AssertionError("deep copy")):
            for code in ("x = 1\nx", "x = 1\ny = x\ny", "x = 1\nx"):
                ac.complete_rest(code, code.count("\n"), len(code.rsplit("\n",1)[-1]))
        pending = [ac._parser_trie_root]
        while pending:
            node = pending.pop()
            self.assertEqual(node["parser"].parser_state.value_stack, [])
            self.assertEqual(node["parser"].parser_state.parse_conf.callbacks, {})
            pending.extend(node["children"].values())
        ac.reset_incremental()
        self.assertIsNone(ac._parser_trie_root)


if __name__ == "__main__":
    unittest.main()
