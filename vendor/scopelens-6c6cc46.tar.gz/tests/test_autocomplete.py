from __future__ import annotations

import unittest

from scopelens import analyzer
from scopelens.analyzer import CursorPosition
from scopelens.member_provider import JediModuleMemberProvider, attribute_context_at


class AutocompleteTests(unittest.TestCase):
    def test_expression_hole_after_for_in_uses_grammar_completion(self) -> None:
        code = "[i for i in "
        completed, prefix, renamed = analyzer._complete_code(
            code,
            CursorPosition(0, len(code)),
        )

        self.assertEqual(prefix, "")
        self.assertTrue(renamed)
        self.assertEqual(completed.count(analyzer.MASKER), 1)
        self.assertIn("]", completed)

        probe = analyzer._inject_candidates(completed, {"i_____NAME_SUFFIX_", "range"})
        self.assertIn("i_____NAME_SUFFIX_", analyzer._undefined_names(probe))

    def test_existing_name_prefix_still_completes(self) -> None:
        code = "apple_count = 1\napplication_state = 2\nresult = app\n"
        names = {
            item.label
            for item in analyzer.available_names(
                code,
                CursorPosition(2, len("result = app")),
            )
        }

        self.assertIn("apple_count", names)
        self.assertIn("application_state", names)

    def test_if_body_completion_renders_tail_at_matching_indent(self) -> None:
        # Regression: the grammar tail used to render standalone at indent 0, so a
        # closing `elif` landed at column 0 and the synthesized program failed to
        # parse. Pyflakes then reported only a syntax error (no undefined names),
        # so every candidate -- including genuinely undefined ones -- survived.
        code = (
            "import pandas as pd\n"
            "def task_func(arg):\n"
            "    df = pd.DataFrame(arg)\n"
            "    if not df.empty:\n"
            "        fig, ax = plt"
        )
        completed, prefix, renamed = analyzer._complete_code(
            code, CursorPosition(4, len("        fig, ax = plt"))
        )

        self.assertEqual(prefix, "plt")
        self.assertTrue(renamed)

        # The injected program must parse: an undefined renamed name is reported,
        # which only happens when pyflakes gets past the syntax stage.
        probe = analyzer._inject_candidates(
            completed, {"plt_____NAME_SUFFIX_", "df_____NAME_SUFFIX_"}
        )
        undefined = analyzer._undefined_names(probe)
        self.assertIn("plt_____NAME_SUFFIX_", undefined)
        self.assertNotIn("df_____NAME_SUFFIX_", undefined)

    def test_available_names_excludes_undefined_name_in_if_body(self) -> None:
        base = (
            "import pandas as pd\n"
            "def task_func(arg):\n"
            "    df = pd.DataFrame(arg)\n"
            "    if not df.empty:\n"
        )

        plt_names = {
            item.label
            for item in analyzer.available_names(
                base + "        fig, ax = plt",
                CursorPosition(4, len("        fig, ax = plt")),
            )
        }
        self.assertNotIn("plt", plt_names)

        df_names = {
            item.label
            for item in analyzer.available_names(
                base + "        x = d",
                CursorPosition(4, len("        x = d")),
            )
        }
        self.assertIn("df", df_names)

    def test_emptyable_repetition_resolves_to_empty(self) -> None:
        # `elifs: elif_*` can derive nothing; its shortest realization is empty.
        # Previously the empty production was skipped, forcing one concrete
        # `elif __name__ : __name__` clause into every completed `if`.
        replace_table = analyzer._get_autocompleter().replace_table
        self.assertEqual(replace_table["elifs"], [])
        self.assertNotEqual(replace_table["elif_"], [])

    def test_completed_if_condition_probe_is_valid_python(self) -> None:
        # An undefined name in an if-CONDITION (not body) closes the `if` via a
        # nested `elifs`/`suite` expansion. Rendering those recursively used to
        # restart indent state, dropping the closing clause to column 0; the
        # completed probe must now be valid Python so pyflakes can resolve names.
        import ast

        code = "import cv2\ndef task_func(path):\n    if not os"
        completed, _prefix, _renamed = analyzer._complete_code(
            code, CursorPosition(2, len("    if not os"))
        )
        probe = analyzer._inject_candidates(
            completed, {"cv2_____NAME_SUFFIX_", "os_____NAME_SUFFIX_"}
        )
        ast.parse(probe)  # must not raise SyntaxError

    def test_undefined_module_in_if_condition_is_excluded(self) -> None:
        # The 8 BigCodeBench/HumanEval `uv` regressions: a bare module name used
        # without import (np/os/string) inside an if-condition leaked because the
        # broken probe made pyflakes report a syntax error instead of the name.
        code = "import cv2\ndef task_func(path):\n    if not os"
        names = {
            item.label
            for item in analyzer.available_names(
                code, CursorPosition(2, len("    if not os"))
            )
        }
        self.assertNotIn("os", names)

        # a name bound in the same scope is still offered
        defined = {
            item.label
            for item in analyzer.available_names(
                "import cv2\ndef task_func(path):\n    if not pa",
                CursorPosition(2, len("    if not pa")),
            )
        }
        self.assertIn("path", defined)

    def test_attribute_context_detects_module_prefix(self) -> None:
        context = attribute_context_at("import numpy as np\nnp.ar", 1, len("np.ar"))

        self.assertIsNotNone(context)
        assert context is not None
        self.assertEqual(context.base, "np")
        self.assertEqual(context.prefix, "ar")
        self.assertEqual(context.base_end_character, 2)

    def test_jedi_module_member_provider_filters_non_modules(self) -> None:
        provider = JediModuleMemberProvider(jedi_module=_FakeJedi("class", ["cwd"]))

        members = provider.complete("from pathlib import Path\nPath.", 1, len("Path."))

        self.assertEqual(members, [])

    def test_jedi_module_member_provider_returns_module_members(self) -> None:
        fake_jedi = _FakeJedi("module", ["array", "arange", "for", "not-valid", "array"])
        provider = JediModuleMemberProvider(jedi_module=fake_jedi)

        members = provider.complete("import numpy as np\nnp.ar", 1, len("np.ar"))

        self.assertIsNotNone(members)
        assert members is not None
        self.assertEqual([member.label for member in members], ["array", "arange"])
        # module-ness is resolved with goto at the base end; members are then
        # enumerated right after the base's dot (prefix-independent, cacheable).
        self.assertEqual(fake_jedi.scripts[0].goto_calls, [(2, 2)])
        self.assertEqual(fake_jedi.scripts[1].complete_calls, [(2, 3)])

    def test_available_names_uses_module_members_for_attribute_context(self) -> None:
        original_provider = analyzer._member_provider
        analyzer._member_provider = JediModuleMemberProvider(
            jedi_module=_FakeJedi("module", ["array", "arange"])
        )
        try:
            names = {
                item.label
                for item in analyzer.available_names(
                    "import numpy as np\napple_count = 1\nnp.ar",
                    CursorPosition(2, len("np.ar")),
                )
            }
        finally:
            analyzer._member_provider = original_provider

        self.assertEqual(names, {"array", "arange"})


class _FakeJedi:
    def __init__(self, inferred_type: str, completion_names: list[str]) -> None:
        self.inferred_type = inferred_type
        self.completion_names = completion_names
        self.scripts: list[_FakeScript] = []

    def Script(self, code: str, path: str | None = None):
        script = _FakeScript(self, code, path)
        self.scripts.append(script)
        return script


class _FakeScript:
    def __init__(self, jedi: _FakeJedi, code: str, path: str | None) -> None:
        self.jedi = jedi
        self.code = code
        self.path = path
        self.infer_calls: list[tuple[int, int]] = []
        self.complete_calls: list[tuple[int, int]] = []
        self.goto_calls: list[tuple[int, int]] = []

    def infer(self, line: int, column: int):
        self.infer_calls.append((line, column))
        return [_FakeName(self.jedi.inferred_type)]

    def goto(self, line: int, column: int, follow_imports: bool = False):
        self.goto_calls.append((line, column))
        return [_FakeName(self.jedi.inferred_type, full_name="fakemodule")]

    def complete(self, line: int, column: int):
        self.complete_calls.append((line, column))
        return [_FakeCompletion(name) for name in self.jedi.completion_names]


class _FakeName:
    def __init__(self, name_type: str, full_name: str | None = None) -> None:
        self.type = name_type
        self.full_name = full_name


class _FakeCompletion:
    def __init__(self, name: str) -> None:
        self.name = name
        self.type = "function"


if __name__ == "__main__":
    unittest.main()
