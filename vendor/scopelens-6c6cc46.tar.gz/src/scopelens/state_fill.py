"""Standalone LALR "fill the rest" completion.

Extracted from tag-lark's ``StateMapV2`` / ``ParserState.fill_symbols`` with the
TG-tag-specific paths (TagNonTerminal / 'tagrule' / 'stag') removed, so it does
NOT depend on the tag-lark fork. It works against any lark LALR ``parser_state``
that exposes:

    parser_state.state_stack                           # [state_id | item_set, ...]
    parser_state.parse_conf.parse_table.idx_to_state   # state_id -> item set (RulePtr list)

and the standard RulePtr shape (``.index``, ``.rule.origin.name``,
``.rule.expansion[i].name``).

Unlike a naive ``_trace`` while-loop (which can spin forever on dead-end states),
``StateMapV2`` builds an explicit DAG over rule-pointer vertices and walks it with
a visited set / Dijkstra, so it always terminates and returns the *shortest*
completion.
"""

from collections import defaultdict
from queue import PriorityQueue


def rptr2vtx(ruleptr):
    sym = str(ruleptr.rule.origin.name)
    rule = tuple(ruleptr.rule.expansion)
    ptr = ruleptr.index
    return (sym, rule, ptr)


class StateMapV2:
    def __init__(self, state):
        self.repr_sym = None
        self.repr_ruleptr = []

        self.sym_rule_to_idx = defaultdict(dict)
        self.sym_idx_to_rule = defaultdict(dict)
        self.sym_idx_to_meta = defaultdict(dict)
        self.sym_to_idx = {}
        self.idx_to_sym = {}

        self.is_bottom = False

        self.edges = defaultdict(list)
        self.back_edges = defaultdict(list)

        for ruleptr in state:
            ptr = ruleptr.index
            rule = ruleptr.rule
            lhs_sym = str(rule.origin.name)
            nxt_sym = rule.expansion[ptr].name if ptr < len(rule.expansion) else None

            if ptr > 0 or lhs_sym.startswith('$root_'):
                self.repr_ruleptr.append(ruleptr)
                if lhs_sym.startswith('$root_'):
                    self.is_bottom = True
                else:
                    if self.repr_sym is not None:
                        assert self.repr_sym == ruleptr.rule.expansion[ptr - 1], \
                            "INVARIANT FAILED: multiple representation symbols in state"
                    self.repr_sym = ruleptr.rule.expansion[ptr - 1]

            if lhs_sym not in self.sym_to_idx:
                idx = len(self.sym_to_idx)
                self.sym_to_idx[lhs_sym] = idx
                self.idx_to_sym[idx] = lhs_sym

            if nxt_sym is not None and nxt_sym not in self.sym_to_idx:
                idx = len(self.sym_to_idx)
                self.sym_to_idx[nxt_sym] = idx
                self.idx_to_sym[idx] = nxt_sym

            if tuple(rule.expansion) not in self.sym_rule_to_idx[lhs_sym]:
                idx = len(self.sym_rule_to_idx[lhs_sym])
                self.sym_rule_to_idx[lhs_sym][tuple(rule.expansion)] = idx
                self.sym_idx_to_rule[lhs_sym][idx] = tuple(rule.expansion)
                self.sym_idx_to_meta[lhs_sym][idx] = rule

        self.build_edges()

    def check_fun(self, check_type):
        if check_type == 'remainder':
            def check(cur, nxt, cur_check):
                (nxt_sym_idx, nxt_rule_idx, nxt_ptr) = nxt
                nxt_sym = self.idx_to_sym[nxt_sym_idx]
                nxt_rule = self.sym_idx_to_rule[nxt_sym][nxt_rule_idx]
                remainder = nxt_rule[nxt_ptr + 1:]
                return cur_check + remainder
            return tuple(), check
        else:
            return True, lambda cur, nxt, cur_check: True

    def build_edges(self):
        queue = []
        for ruleptr in self.repr_ruleptr:
            ptr = ruleptr.index
            rule = ruleptr.rule
            lhs_sym = str(rule.origin.name)
            rule_idx = self.sym_rule_to_idx[lhs_sym][tuple(rule.expansion)]
            queue.append((lhs_sym, rule_idx, ptr))

        qidx = 0
        while qidx < len(queue):
            c_sym, c_rule_idx, c_ptr = queue[qidx]
            c_sym_idx = self.sym_to_idx[c_sym]
            cur_vtx = (c_sym_idx, c_rule_idx, c_ptr)
            qidx += 1

            if c_ptr >= len(self.sym_idx_to_rule[c_sym][c_rule_idx]):
                continue
            nxt_sym = self.sym_idx_to_rule[c_sym][c_rule_idx][c_ptr].name
            nxt_sym_idx = self.sym_to_idx[nxt_sym]

            for nxt_rule_idx in self.sym_idx_to_rule[nxt_sym]:
                nxt_vtx = (nxt_sym_idx, nxt_rule_idx, 0)
                if self.validate_edge(cur_vtx, nxt_vtx):
                    self.edges[cur_vtx].append(nxt_vtx)
                    self.back_edges[nxt_vtx].append(cur_vtx)
                    if nxt_vtx not in queue:
                        queue.append((nxt_sym, nxt_rule_idx, 0))

    def validate_edge(self, cur_vtx, nxt_vtx):
        if cur_vtx == nxt_vtx:
            return False
        if nxt_vtx in self.edges[cur_vtx]:
            return False
        stack = [nxt_vtx]
        visited = {nxt_vtx}
        while stack:
            vtx = stack.pop()
            if vtx == cur_vtx:
                return False
            for adj in self.edges[vtx]:
                if adj not in visited:
                    visited.add(adj)
                    stack.append(adj)
        return True

    def get_paths(self, start_ruleptr, nondeterministic=False, check='remainder'):
        (start_sym, start_rule, start_ptr) = start_ruleptr
        start_vtx = (
            self.sym_to_idx[start_sym],
            self.sym_rule_to_idx[start_sym][start_rule],
            start_ptr,
        )

        queue = [start_vtx]
        visited = defaultdict(dict) if nondeterministic else {}
        start_init, check_fun = self.check_fun(check)

        if nondeterministic:
            visited[start_vtx][start_init] = False
        else:
            visited[start_vtx] = start_init

        qidx = 0
        while qidx < len(queue):
            cur_vtx = queue[qidx]
            qidx += 1
            for adj in self.back_edges[cur_vtx]:
                if nondeterministic:
                    for cur_check, used in visited[cur_vtx].items():
                        if used:
                            continue
                        new_check = check_fun(cur_vtx, adj, cur_check)
                        if new_check not in visited[adj]:
                            visited[adj][new_check] = False
                            queue.append(adj)
                else:
                    if adj not in visited:
                        visited[adj] = check_fun(cur_vtx, adj, visited[cur_vtx])
                        queue.append(adj)

        result = {}
        for ruleptr in self.repr_ruleptr:
            ptr = ruleptr.index
            rule = tuple(ruleptr.rule.expansion)
            lhs_sym = str(ruleptr.rule.origin.name)
            sym_idx = self.sym_to_idx[lhs_sym]
            rule_idx = self.sym_rule_to_idx[lhs_sym][rule]
            vtx = (sym_idx, rule_idx, ptr)
            if vtx in visited:
                result[(lhs_sym, rule, ptr)] = visited[vtx]
        return result

    def get_shortest_paths(self, start_ruleptr):
        (start_sym, start_rule, start_ptr) = start_ruleptr
        start_vtx = (
            self.sym_to_idx[start_sym],
            self.sym_rule_to_idx[start_sym][start_rule],
            start_ptr,
        )

        queue = PriorityQueue()
        visited = {start_vtx: []}
        distance = {start_vtx: 0}
        queue.put((0, start_vtx))

        while not queue.empty():
            (dist, cur_vtx) = queue.get()
            if distance[cur_vtx] < dist:
                continue
            for adj in self.back_edges[cur_vtx]:
                (nxt_sym_idx, nxt_rule_idx, nxt_ptr) = adj
                nxt_sym = self.idx_to_sym[nxt_sym_idx]
                nxt_rule = self.sym_idx_to_rule[nxt_sym][nxt_rule_idx]
                remainder = list(nxt_rule[nxt_ptr + 1:])
                if adj not in distance or dist + len(remainder) < distance[adj]:
                    visited[adj] = visited[cur_vtx] + remainder
                    distance[adj] = dist + len(remainder)
                    queue.put((distance[adj], adj))

        result = {}
        for ruleptr in self.repr_ruleptr:
            ptr = ruleptr.index
            rule = tuple(ruleptr.rule.expansion)
            lhs_sym = str(ruleptr.rule.origin.name)
            sym_idx = self.sym_to_idx[lhs_sym]
            rule_idx = self.sym_rule_to_idx[lhs_sym][rule]
            vtx = (sym_idx, rule_idx, ptr)
            if vtx in visited:
                result[(lhs_sym, rule, ptr)] = visited[vtx]
        return result

    def prepare(self):
        for ruleptr in self.repr_ruleptr:
            yield rptr2vtx(ruleptr)


def _resolve_item_set(state_ref, idx_to_state_getter):
    # State-stack entries differ by lark build:
    #   * tag-lark: (states, token_count) tuple -> first element is the ref
    #   * vanilla lark w/ debug=True: the LR item set (frozenset of RulePtr) directly
    #   * int state-id: needs the idx_to_state map to recover the item set
    if isinstance(state_ref, tuple) and len(state_ref) == 2:
        state_ref = state_ref[0]
    if isinstance(state_ref, int):
        return idx_to_state_getter()[state_ref]
    return state_ref


def fill_tail(parser_state, fill_type='shortest', cache=None):
    """Return terminal/symbol NAMES that complete the current (partial) parse.

    Drop-in replacement for the buggy ``_trace``-based tail computation: walks the
    LALR state stack via StateMapV2 (a DAG) so it always terminates.

    ``cache`` maps an LALR state -> its StateMapV2. The same finite set of LALR
    states recurs across every call, so passing a persistent dict (bounded by the
    number of parse-table states) builds each state's DAG once instead of per
    call -- this is the StateMap reuse sem-lark keeps in ``AttributeFlow._state_maps``.
    When None, a fresh per-call cache is used (legacy behaviour).
    """
    state_stack = parser_state.state_stack

    # Only needed when state_stack holds int state-ids; fetched lazily so vanilla
    # lark (whose ParseTable lacks idx_to_state, but whose debug stack already
    # holds item sets) does not trip over the missing attribute.
    def idx_to_state_getter():
        return parser_state.parse_conf.parse_table.idx_to_state

    if cache is None:
        cache = {}

    def smap(idx):  # idx counted from the TOP of the stack
        ref = state_stack[-(idx + 1)]
        key = ref[0] if (isinstance(ref, tuple) and len(ref) == 2) else ref
        if key not in cache:
            cache[key] = StateMapV2(_resolve_item_set(ref, idx_to_state_getter))
        return cache[key]

    if fill_type == 'shortest':
        top = smap(0)
        candidates = {(sym, rule, ptr): list(rule)[ptr:] for (sym, rule, ptr) in top.prepare()}
        for i in range(1, len(state_stack)):
            sm = smap(i)
            new_candidates = {}
            for (src_sym, src_rule, src_ptr), fills in candidates.items():
                results = sm.get_shortest_paths((src_sym, src_rule, src_ptr - 1))
                src_dist = len(fills)
                for (dst_sym, dst_rule, dst_ptr), syms in results.items():
                    dst_vtx = (dst_sym, dst_rule, dst_ptr)
                    if dst_vtx not in new_candidates or src_dist + len(syms) < len(new_candidates[dst_vtx]):
                        new_candidates[dst_vtx] = fills + syms
            candidates = new_candidates
        argmin, min_cost = [], None
        for fills in candidates.values():
            if min_cost is None or len(fills) < min_cost:
                min_cost, argmin = len(fills), fills
        fills = argmin
    else:
        top = smap(0)
        (sym, rule, ptr) = next(top.prepare())
        fills = list(rule[ptr:])
        for i in range(1, len(state_stack)):
            sm = smap(i)
            results = sm.get_paths((sym, rule, ptr - 1), check='remainder')
            for vtx in results:
                fills = fills + list(results[vtx])
                break

    return [str(getattr(s, "name", s)) for s in fills]
