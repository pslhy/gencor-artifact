from __future__ import annotations

import argparse
import logging
import sys
from collections.abc import Iterable
from typing import Optional, Union

from lsprotocol import types
from pygls.lsp.server import LanguageServer

from scopelens import __version__
from scopelens import analyzer
from scopelens.analyzer import CursorPosition, DocumentSnapshot, NameCandidate

LOGGER = logging.getLogger("scopelens")


class ScopeLensServer(LanguageServer):
    """Small completion-only language server for Python visible names."""

    def __init__(self) -> None:
        super().__init__("scopelens", __version__)


server = ScopeLensServer()


@server.feature(
    types.TEXT_DOCUMENT_COMPLETION,
    types.CompletionOptions(trigger_characters=[".", "_"]),
)
def completions(params: types.CompletionParams):
    document = server.workspace.get_text_document(params.text_document.uri)
    position = CursorPosition(
        line=params.position.line,
        character=params.position.character,
    )

    try:
        candidates = analyzer.available_names(
            _document_source(document),
            position,
            uri=params.text_document.uri,
        )
    except Exception:
        LOGGER.exception("available_names failed")
        candidates = ()

    return types.CompletionList(
        is_incomplete=False,
        items=list(_completion_items(candidates)),
    )


@server.feature(types.TEXT_DOCUMENT_DID_OPEN)
def did_open(ls: ScopeLensServer, params: types.DidOpenTextDocumentParams) -> None:
    try:
        document = ls.workspace.get_text_document(params.text_document.uri)
        analyzer.did_open(_snapshot(document))
    except Exception:
        LOGGER.exception("did_open hook failed")


@server.feature(types.TEXT_DOCUMENT_DID_CHANGE)
def did_change(ls: ScopeLensServer, params: types.DidChangeTextDocumentParams) -> None:
    try:
        document = ls.workspace.get_text_document(params.text_document.uri)
        analyzer.did_change(_snapshot(document))
    except Exception:
        LOGGER.exception("did_change hook failed")


@server.feature(types.TEXT_DOCUMENT_DID_SAVE, types.SaveOptions(include_text=True))
def did_save(ls: ScopeLensServer, params: types.DidSaveTextDocumentParams) -> None:
    try:
        document = ls.workspace.get_text_document(params.text_document.uri)
        analyzer.did_save(_snapshot(document), text=params.text)
    except Exception:
        LOGGER.exception("did_save hook failed")


@server.feature(types.TEXT_DOCUMENT_DID_CLOSE)
def did_close(_ls: ScopeLensServer, params: types.DidCloseTextDocumentParams) -> None:
    try:
        analyzer.did_close(params.text_document.uri)
    except Exception:
        LOGGER.exception("did_close hook failed")


# Custom notification: client sends this at a test boundary (reset) so each
# test starts with a cold StateMapV2 cache and its timing is order-independent.
@server.feature("scopelens/resetStateMapCache")
def reset_state_map_cache(_ls: ScopeLensServer, *_args) -> None:
    try:
        analyzer.clear_state_map_cache()
    except Exception:
        LOGGER.exception("reset_state_map_cache hook failed")


@server.feature("scopelens/undefinedModuleMembers")
def undefined_module_members(_ls: ScopeLensServer, params):
    """Custom request: `module.member` accesses the module does not define."""
    try:
        uri = params["uri"] if isinstance(params, dict) else params.uri
        document = server.workspace.get_text_document(uri)
        return analyzer.undefined_module_members(_document_source(document))
    except Exception:
        LOGGER.exception("undefined_module_members hook failed")
        return []


@server.feature("scopelens/isModule")
def is_module(_ls: ScopeLensServer, params) -> bool:
    """Custom request: does the expression at (line, character) infer to a module?

    Params are sent flat ({uri, line, character}) so we don't depend on pygls
    structuring a custom method's payload into a typed object.
    """
    try:
        uri = params["uri"] if isinstance(params, dict) else params.uri
        line = params["line"] if isinstance(params, dict) else params.line
        character = params["character"] if isinstance(params, dict) else params.character
        document = server.workspace.get_text_document(uri)
        position = CursorPosition(line=line, character=character)
        return analyzer.is_module(_document_source(document), position)
    except Exception:
        LOGGER.exception("is_module hook failed")
        return False


def _document_source(document) -> str:
    source = getattr(document, "source", None)
    if source is not None:
        return source
    return "\n".join(document.lines)


def _snapshot(document) -> DocumentSnapshot:
    return DocumentSnapshot(
        uri=document.uri,
        source=_document_source(document),
        language_id=getattr(document, "language_id", None),
        version=getattr(document, "version", None),
    )


def _completion_items(candidates: Iterable[Union[str, NameCandidate]]):
    for payload in _completion_payloads(candidates):
        yield types.CompletionItem(
            label=payload["label"],
            kind=types.CompletionItemKind.Variable,
            detail=payload.get("detail"),
        )


def _completion_payloads(candidates: Iterable[Union[str, NameCandidate]]):
    seen: set[str] = set()
    for candidate in candidates:
        if isinstance(candidate, NameCandidate):
            label = candidate.label
            detail = candidate.detail
        else:
            label = str(candidate)
            detail = None

        if not label or label in seen:
            continue

        seen.add(label)
        yield {"label": label, "kind": types.CompletionItemKind.Variable.value, "detail": detail}


def main(argv: Optional[list[str]] = None) -> None:
    parser = argparse.ArgumentParser(description="Run the ScopeLens language server.")
    parser.add_argument(
        "--tcp",
        action="store_true",
        help="Run the server over TCP instead of stdio.",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="TCP host used with --tcp.",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=2087,
        help="TCP port used with --tcp.",
    )
    parser.add_argument(
        "--log-level",
        default="WARNING",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="Server log level. Logs are written to stderr.",
    )
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        stream=sys.stderr,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    LOGGER.info("Starting ScopeLens %s", __version__)
    if args.tcp:
        server.start_tcp(args.host, args.port)
    else:
        server.start_io()


if __name__ == "__main__":
    main()
