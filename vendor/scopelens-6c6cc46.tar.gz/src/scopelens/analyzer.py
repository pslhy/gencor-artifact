from __future__ import annotations

import builtins
import io
import keyword
import re
import time
import tokenize
from dataclasses import dataclass
from typing import Iterable, Optional, Union

from pyflakes.api import check
from pyflakes.reporter import Reporter

from scopelens.autocomplete import MASKER, AutoCompleter
from scopelens.member_provider import JediModuleMemberProvider


@dataclass(frozen=True)
class CursorPosition:
    """Zero-based cursor position from the Language Server Protocol."""

    line: int
    character: int


@dataclass(frozen=True)
class NameCandidate:
    """A name visible at the cursor position."""

    label: str
    detail: Optional[str] = None


@dataclass(frozen=True)
class DocumentSnapshot:
    """A workspace document snapshot after pygls has applied LSP sync events."""

    uri: str
    source: str
    language_id: Optional[str] = None
    version: Optional[int] = None


@dataclass
class DocumentState:
    snapshot: DocumentSnapshot
    candidates: set[str]
    version: Optional[int] = None


PYFLAKE_DEFAULT_NAMES = {
    "__name__",
    "__loader__",
    "__package__",
    "__spec__",
    "__path__",
    "__file__",
    "__cached__",
    "__annotations__",
    "__dict__",
    "__builtins__",
    "__doc__",
    "object",
    "staticmethod",
    "classmethod",
    "type",
    "super",
    "function",
    "ellipsis",
}
BUILTIN_NAMES = {
    name
    for name in dir(builtins)
    if name.isidentifier() and not keyword.iskeyword(name)
}
DEFAULT_NAMES = PYFLAKE_DEFAULT_NAMES | BUILTIN_NAMES
# DEFAULT_NAMES entries that are NOT real builtins: module dunders (context
# dependent) and a couple of type names like `function`/`ellipsis` that are not
# actually in scope. The original code relies on pyflakes to prune the non-real
# ones, so these must still be injected/checked even without a `del` -- only the
# real builtins (BUILTIN_NAMES) are unconditionally in scope.
NON_BUILTIN_DEFAULTS = DEFAULT_NAMES - BUILTIN_NAMES
NAME_SUFFIX = "_____NAME_SUFFIX_"

_documents: dict[str, DocumentState] = {}
_autocompleter: Optional[AutoCompleter] = None
_member_provider: Optional[JediModuleMemberProvider] = None
_undefined_name_re = re.compile(
    r".*:(?P<line>\d+)(?::(?P<column>\d+))?:\s*undefined name '(?P<name>[^']+)'"
)


def did_open(document: DocumentSnapshot) -> None:
    """Handle textDocument/didOpen after the workspace document is available."""

    _documents[document.uri] = _state_from_document(document)


def did_change(document: DocumentSnapshot) -> None:
    """Handle textDocument/didChange after pygls has applied the change."""

    _documents[document.uri] = _state_from_document(document)


def did_save(document: DocumentSnapshot, text: Optional[str] = None) -> None:
    """Handle textDocument/didSave."""

    if text is None:
        _documents[document.uri] = _state_from_document(document)
    else:
        saved = DocumentSnapshot(
            uri=document.uri,
            source=text,
            language_id=document.language_id,
            version=document.version,
        )
        _documents[document.uri] = _state_from_document(saved)


def did_close(uri: str) -> None:
    """Handle textDocument/didClose after pygls has removed the document."""

    _documents.pop(uri, None)


def available_names(
    code: str,
    position: CursorPosition,
    *,
    uri: Optional[str] = None,
    extra_names: Optional[Iterable[str]] = None,
) -> Iterable[Union[str, NameCandidate]]:
    """Return names available at ``position``.

    The implementation mirrors the Pyflakes-based filtering used by gencor's
    LSPPyflake: synthesize a complete program around the cursor, replace the
    cursor name with all known candidates, then keep names Pyflakes does not
    report as undefined.
    """

    module_members = _complete_module_members(code, position)
    if module_members is not None:
        return module_members

    started_at = time.time()
    prefix_code, prefix, renamed_names = _complete_code(code, position)
    candidates = _candidate_pool(code, uri)
    candidates.update(_clean_names(extra_names or ()))

    dynamic_names = {
        name
        for name in candidates
        if name.isidentifier()
        and not keyword.iskeyword(name)
        and name not in DEFAULT_NAMES
    }
    if renamed_names:
        dynamic_memory = {name + NAME_SUFFIX for name in dynamic_names}
    else:
        dynamic_memory = set(dynamic_names)

    # Builtins/defaults are in scope unless a `del` removed one -- and only `del`
    # can (shadowing a builtin yields a different diagnostic, not "undefined
    # name"). So when the code has no `del`, skip injecting the ~150 default names
    # into pyflakes (a large constant added to the candidate expression it must
    # parse and check) and merge them into the result directly; a `del` present
    # falls back to checking them too.
    if _get_autocompleter().has_del(code):
        memory = set(DEFAULT_NAMES) | dynamic_memory
        always_in_scope: set[str] = set()
    else:
        # Real builtins are in scope; the non-real defaults still need pyflakes
        # to prune them (e.g. `function`/`ellipsis`).
        memory = set(NON_BUILTIN_DEFAULTS) | dynamic_memory
        always_in_scope = set(BUILTIN_NAMES)

    if not memory and not always_in_scope:
        return ()

    undefined = _undefined_names(_inject_candidates(prefix_code, memory)) if memory else set()
    in_scope = always_in_scope | {name for name in memory if name not in undefined}
    available = sorted(
        label
        for label in (_strip_name_suffix(name) for name in in_scope)
        if not prefix or label.startswith(prefix)
    )
    elapsed_ms = (time.time() - started_at) * 1000
    return [
        NameCandidate(name, detail="ScopeLens/Pyflakes %.1f ms" % elapsed_ms)
        for name in available
    ]


def _state_from_document(document: DocumentSnapshot) -> DocumentState:
    return DocumentState(
        snapshot=document,
        candidates=_collect_candidate_names(document.source),
        version=document.version,
    )


def _candidate_pool(code: str, uri: Optional[str]) -> set[str]:
    candidates = set(DEFAULT_NAMES)
    state = _documents.get(uri) if uri is not None else None
    if state is not None and state.snapshot.source == code:
        candidates.update(state.candidates)
    else:
        candidates.update(_collect_candidate_names(code))
    return candidates


def _get_autocompleter() -> AutoCompleter:
    global _autocompleter
    if _autocompleter is None:
        _autocompleter = AutoCompleter()
    return _autocompleter


def clear_state_map_cache() -> None:
    """Drop the AutoCompleter's StateMapV2 cache (keeps the compiled grammar).

    Called at test boundaries so each test's completion timing is independent of
    what ran before it -- the cache re-warms within a few queries, so this costs
    essentially nothing per test.
    """
    if _autocompleter is not None:
        _autocompleter._state_map_cache.clear()
        _autocompleter.reset_incremental()


def _get_member_provider() -> JediModuleMemberProvider:
    global _member_provider
    if _member_provider is None:
        _member_provider = JediModuleMemberProvider()
    return _member_provider


def _complete_module_members(
    code: str,
    position: CursorPosition,
) -> Optional[list[NameCandidate]]:
    members = _get_member_provider().complete(code, position.line, position.character)
    if members is None:
        return None
    return [NameCandidate(member.label, detail=member.detail) for member in members]


def is_module(code: str, position: CursorPosition) -> bool:
    """Whether the expression ending at ``position`` resolves to a Python module.

    Separate from name completion (which serves uv scope checking): this is a
    dedicated jedi type-inference query so callers ask module-ness directly
    rather than reading it off completion-item kinds.
    """
    return _get_member_provider().is_module_at(code, position.line, position.character)


def undefined_module_members(code: str) -> list[dict]:
    """Find ``module.member`` accesses whose base is a module but whose member the
    module does not define (e.g. ``docx.TextDocument``, ``rsa.generate_private_key``).

    Uses the same jedi member provider as the completion path -- so resolution
    happens against the server's own interpreter -- instead of the caller
    re-walking/importing. Returns ``[{"line", "character", "name"}]`` (1-based
    line, 1-based column at the member, ``name`` the dotted access). Chains
    through submodule members and stops at the first non-module.
    """
    import ast

    try:
        tree = ast.parse(code)
    except SyntaxError:
        return []

    provider = _get_member_provider()
    inner = {
        id(n.value)
        for n in ast.walk(tree)
        if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Attribute)
    }

    out: list[dict] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Attribute) or id(node) in inner:
            continue
        if not isinstance(node.ctx, ast.Load):
            continue
        levels, cur = [], node
        while isinstance(cur, ast.Attribute):
            levels.append(cur)
            cur = cur.value
        if not isinstance(cur, ast.Name):
            continue
        levels.reverse()

        dotted = cur.id
        for lv in levels:
            base = lv.value
            if lv.end_lineno != base.end_lineno:
                break  # split across lines -> don't try to locate
            base_line = base.end_lineno - 1
            base_end = base.end_col_offset
            if not provider.is_module_at(code, base_line, base_end):
                break  # base is not a module (or already the tail) -> stop
            members = provider.complete(code, base_line, base_end + 1)
            if not members:
                break  # could not enumerate members -> don't guess
            labels = {m.label for m in members}
            if lv.attr not in labels:
                out.append(
                    {
                        "line": lv.end_lineno,
                        "character": lv.end_col_offset - len(lv.attr) + 1,
                        "name": dotted + "." + lv.attr,
                    }
                )
                break
            dotted = dotted + "." + lv.attr
    return out


def _complete_code(code: str, position: CursorPosition) -> tuple[str, str, bool]:
    try:
        completed, prefix, _line, _character = _get_autocompleter().complete_rest(
            code,
            position.line,
            position.character,
            memory=DEFAULT_NAMES,
            suffix=NAME_SUFFIX,
            rename_names=True,
        )
        return completed, prefix, True
    except Exception:
        completed, prefix = _simple_probe(code, position)
        return completed, prefix, False


def _simple_probe(code: str, position: CursorPosition) -> tuple[str, str]:
    offset = _offset_from_position(code, position)
    start = offset
    while start > 0 and _is_identifier_char(code[start - 1]):
        start -= 1
    prefix = code[start:offset]
    return code[:start] + MASKER + "\n", prefix


def _inject_candidates(code: str, candidates: set[str]) -> str:
    candidate_expr = "(" + ",".join(sorted(candidates)) + ")[0]"
    if MASKER in code:
        return code.replace(MASKER, candidate_expr, 1)
    return code + "\n" + candidate_expr + "\n"


def _clean_names(names: Iterable[str]) -> set[str]:
    cleaned = set()
    for name in names:
        text = str(name).strip()
        if text.isidentifier() and not keyword.iskeyword(text):
            cleaned.add(text)
    return cleaned


def _strip_name_suffix(name: str) -> str:
    if name.endswith(NAME_SUFFIX):
        return name[: -len(NAME_SUFFIX)]
    return name


def _undefined_names(code: str) -> set[str]:
    output = io.StringIO()
    reporter = Reporter(output, output)
    check(code, filename="<scopelens>", reporter=reporter)

    names = set()
    for message in output.getvalue().splitlines():
        match = _undefined_name_re.match(message)
        if match is not None:
            names.add(match.group("name"))
    return names


def _collect_candidate_names(code: str) -> set[str]:
    try:
        return _clean_names(_get_autocompleter().name_candidates(code))
    except Exception:
        pass

    names = set()
    try:
        for token in tokenize.generate_tokens(io.StringIO(code).readline):
            if token.type != tokenize.NAME:
                continue
            if token.string.isidentifier() and not keyword.iskeyword(token.string):
                names.add(token.string)
    except (IndentationError, tokenize.TokenError):
        pass
    return names


def _offset_from_position(code: str, position: CursorPosition) -> int:
    lines = code.splitlines(keepends=True)
    if position.line <= 0:
        return min(position.character, len(code))
    if position.line >= len(lines):
        return len(code)
    return min(
        sum(len(part) for part in lines[: position.line]) + position.character,
        len(code),
    )


def _is_identifier_char(char: str) -> bool:
    return char == "_" or char.isalnum()
