from __future__ import annotations

from collections.abc import Iterator

from lark import Token
from lark.indenter import DedentError
from lark.lark import PostLex


class PythonIndenter(PostLex):
    NL_type = "_NEWLINE"
    COMMENT_type = "COMMENT"
    INDENT_type = "_INDENT"
    DEDENT_type = "_DEDENT"
    tab_len = 4

    def __init__(self) -> None:
        self.indent_level = [0]
        self.tmp_indent = 0
        self.tmp_newline = None

    def process(self, stream: Iterator[Token]) -> Iterator[Token]:
        self.indent_level = [0]
        self.tmp_indent = 0
        self.tmp_newline = None
        return self._process(stream)

    def _process(self, stream: Iterator[Token]) -> Iterator[Token]:
        for token in stream:
            if token.type == self.NL_type:
                self._handle_newline(token)
            elif token.type == self.COMMENT_type:
                if self.tmp_newline is not None:
                    yield self.tmp_newline
                    self.tmp_newline = None
                yield token
            else:
                if self.tmp_newline is not None:
                    yield self.tmp_newline
                    self.tmp_newline = None
                yield from self._handle_non_newline(token)

    def _handle_newline(self, token: Token) -> None:
        try:
            indent_str = token.value.rsplit("\n", 1)[1]
        except IndexError:
            indent_str = ""
        self.tmp_indent = indent_str.count(" ") + indent_str.count("\t") * self.tab_len
        self.tmp_newline = token

    def _handle_non_newline(self, token: Token) -> Iterator[Token]:
        indent = self.tmp_indent
        if indent > self.indent_level[-1]:
            self.indent_level.append(indent)
            yield Token(self.INDENT_type, " " * indent)
        else:
            while indent < self.indent_level[-1]:
                self.indent_level.pop()
                yield Token(self.DEDENT_type, " " * indent)

            if indent != self.indent_level[-1]:
                raise DedentError(
                    "Unexpected dedent to column %s. Expected dedent to %s"
                    % (indent, self.indent_level[-1])
                )

        yield token
