from __future__ import annotations

import json
import re
from importlib import resources
from typing import Any, Optional

import lark
from lark.lexer import LexerThread, Token

from scopelens.python_indenter import PythonIndenter
from scopelens.state_fill import fill_tail

MASKER = "!FILL_NAME!"
SENTINEL = "zzzzz"
NAME_TERMINALS = {"NAME", "MATCH", "CASE"}


def _grammar_text(name: str) -> str:
    grammar = resources.files("scopelens.grammars").joinpath(name).read_text(encoding="utf-8")
    return _strip_tag_lark_annotations(grammar)


def _strip_tag_lark_annotations(grammar: str) -> str:
    grammar = re.sub(r"@(?:OPEN|CLOSED|tag)\b", "", grammar)
    grammar = re.sub(r"%(?:THROW|CATCH)\b", "", grammar)
    return grammar


def _load_terms(name: str) -> dict[str, Any]:
    text = resources.files("scopelens.grammars").joinpath(name).read_text(encoding="utf-8")
    return json.loads(text)


def _symbol_name(symbol: Any) -> str:
    name = getattr(symbol, "name", symbol)
    if isinstance(name, Token):
        return name.value
    return str(name)


# NOTE: _find_start / _trace are the legacy LALR tail-completion helpers. They are
# no longer used by complete_grammar(), which now delegates to
# state_fill.fill_tail() (StateMapV2 DAG walk). The old _trace while-loop could spin
# forever on dead-end states (e.g. HumanEval/1 `if not <name>`); fill_tail terminates.
# Kept for reference/comparison only.
def _find_start(state_stack, parser):
    for rule_ptr in _state_rules(state_stack[-1], parser):
        if rule_ptr.index > 0:
            return rule_ptr
    return None


def _state_rules(state_ref, parser):
    if not isinstance(state_ref, int):
        return state_ref

    parse_table = parser.parser_state.parse_conf.parse_table
    if hasattr(parse_table, "idx_to_state"):
        return parse_table.idx_to_state[state_ref]

    state = parse_table.states[state_ref]
    if hasattr(state, "items"):
        return ()
    return state


def _trace(state_stack, start, index, parser):
    terminal_sequence = []
    while True:
        origin = _symbol_name(start.rule.origin)
        candidate = None

        for rule_ptr in _state_rules(state_stack[index], parser):
            if len(rule_ptr.rule.expansion) == rule_ptr.index:
                continue
            expansion_name = _symbol_name(rule_ptr.rule.expansion[rule_ptr.index])
            rule_origin = _symbol_name(rule_ptr.rule.origin)
            if expansion_name == origin and rule_origin != expansion_name:
                if candidate is None:
                    candidate = rule_ptr
                elif len(candidate.rule.expansion[candidate.index :]) > len(
                    rule_ptr.rule.expansion[rule_ptr.index :]
                ):
                    candidate = rule_ptr

        if candidate is not None:
            terminal_sequence += candidate.rule.expansion[candidate.index + 1 :]
            start = candidate

        if start.index > 0 or _symbol_name(start.rule.origin).startswith("$root_"):
            break

    return start, terminal_sequence


class ReplacementTable:
    class RuleIndegree:
        def __init__(self, rule) -> None:
            self.rule = rule
            self.indegree = len(rule.expansion)

        def remove(self, symbol: str) -> bool:
            count = sum(1 for item in self.rule.expansion if _symbol_name(item) == symbol)
            self.indegree -= count
            return self.indegree == 0

    def __init__(self, terms_file: str, lark_obj: lark.Lark) -> None:
        self.expansion_to_rules = {}
        self.lark = lark_obj
        self.can_replace = {}
        self.replacement_table = {}
        self.dict = {}

        self._prepare_expansion_to_rules()
        self._load_terms(terms_file)
        self._load_default_terms()
        self._iterate()
        self._initialize_dict()

    def _prepare_expansion_to_rules(self) -> None:
        for rule in self.lark.rules:
            name = _symbol_name(rule.origin)
            rule_indegree = self.RuleIndegree(rule)
            if not rule.expansion:
                # An empty production lets this nonterminal derive nothing, which is
                # the shortest possible realization. Register it so emptyable rules
                # (x*, x?, optional clauses like `elifs`) resolve to empty instead of
                # being forced to one concrete iteration -- the latter injects spurious
                # tokens (e.g. a dangling `elif`) into the completed program.
                self.can_replace.setdefault(name, rule)
                self.replacement_table.setdefault(name, [])
                continue
            if rule_indegree.indegree == 0:
                self.can_replace[name] = rule
            for symbol in rule.expansion:
                symbol_name = _symbol_name(symbol)
                self.expansion_to_rules.setdefault(symbol_name, set()).add(rule_indegree)

    def _propagate(self, symbol: str, updates: Optional[dict[str, Any]] = None):
        if updates is None:
            updates = {}
        for rule_indegree in self.expansion_to_rules.get(symbol, ()):
            next_name = _symbol_name(rule_indegree.rule.origin)
            if (
                next_name not in self.can_replace
                and next_name not in self.replacement_table
                and next_name not in updates
                and rule_indegree.remove(symbol)
            ):
                updates[next_name] = rule_indegree.rule
                updates.update(self._propagate(next_name, updates))
        return updates

    def _load_terms(self, terms_file: str) -> None:
        self.replacement_table.update(_load_terms(terms_file))
        for key in list(self.replacement_table):
            self.can_replace.update(self._propagate(key))

    def _load_default_terms(self) -> None:
        for term_name, term in self.lark._terminals_dict.items():
            if term_name in self.replacement_table:
                continue
            if isinstance(term.pattern, lark.lexer.PatternRE) and not term_name.startswith("__IGNORE_"):
                raise NotImplementedError(
                    "Regex terminal needs an explicit replacement: %s" % term_name
                )
            if isinstance(term.pattern, lark.lexer.PatternStr):
                self.replacement_table[term_name] = term.pattern.value
            self.can_replace.update(self._propagate(term_name))

    def _iterate(self) -> None:
        rule_count = len(self.lark.rules)
        previous_count = -1
        while previous_count != len(self.can_replace) and len(self.can_replace) < rule_count:
            previous_count = len(self.can_replace)
            updates = {}
            for name, rule in list(self.can_replace.items()):
                if name in self.replacement_table:
                    continue
                self.replacement_table[name] = [_symbol_name(symbol) for symbol in rule.expansion]
                updates.update(self._propagate(name, updates))
            self.can_replace.update(updates)

    def _resolve(self, symbol: str) -> str:
        rule = self.replacement_table[symbol]
        if isinstance(rule, list):
            return " ".join(self._resolve(item) for item in rule)
        return symbol

    def _initialize_dict(self) -> None:
        for key, value in self.replacement_table.items():
            if isinstance(value, list):
                self.dict[key] = " ".join(self._resolve(item) for item in value).split()
            else:
                self.dict[key] = value

    def __getitem__(self, key: str):
        return self.dict[key]


class _ParserTrieCursor:
    """A movable cursor over cached feed_token outcomes, with no output caches."""

    def __init__(self, node):
        self.node = node

    @property
    def parser(self):
        return self.node["parser"]

    def copy(self):
        return _ParserTrieCursor(self.node)

    def feed_token(self, token: Token):
        key = (token.type, token.value)
        child = self.node["children"].get(key)
        if child is None:
            # Only LR state is needed; rendering uses the separate fed terminals.
            parser = self.parser.copy(deepcopy_values=False)
            expected = None
            try:
                parser.feed_token(token)
            except lark.exceptions.UnexpectedToken as exc:
                expected = frozenset(exc.expected)
            parser.parser_state.value_stack = []
            child = {"parser": parser, "children": {}, "expected": expected}
            self.node["children"][key] = child
        self.node = child
        if child["expected"] is not None:
            # Replay the parsing failure and its state; the caller owns recovery.
            # Do not retain exception objects and their tracebacks in the trie.
            raise lark.exceptions.UnexpectedToken(
                token, child["expected"], state=self.parser.parser_state
            )


class AutoCompleter:
    def __init__(
        self,
        grammar_file: str = "indent_python_tcf_grammar.lark",
        terms_file: str = "terms.json",
    ) -> None:
        self.lark = lark.Lark(
            _grammar_text(grammar_file),
            parser="lalr",
            start="start",
            postlex=PythonIndenter(),
            propagate_positions=True,
            keep_all_tokens=False,
            debug=True,
        )
        self.parser = None
        self.replace_table = ReplacementTable(terms_file, self.lark)
        # Persistent LALR-state -> StateMapV2 cache, reused across every
        # complete_grammar() call. Bounded by the number of parse-table states
        # (a fixed property of the grammar), so it does not grow with input.
        self._state_map_cache: dict = {}
        # Only parsing outcomes live in the trie. Fed tokens and rendered code
        # retain their separate, last-stable-prefix cache in _inc.
        self._parser_trie_root: Optional[dict] = None
        self._inc: Optional[dict] = None
        # Incremental raw lexing: reuse a stream's previous raw tokens and re-lex
        # only the appended delta, then run the (cheap, ~6%) postlex in full.
        # Keyed per stream ("plain" full code, "sentinel" cursor-probe code) so
        # the two lexes in complete_rest don't thrash a single baseline.
        self._raw_lexer = self.lark._build_lexer()
        self._postlex = self.lark.lexer_conf.postlex
        self._inc_indenter = PythonIndenter()   # resumable postlex for the delta
        self._raw_streams: dict = {}

    def complete_rest(
        self,
        code: str,
        line: int,
        character: int,
        masker: str = MASKER,
        memory: Optional[set[str]] = None,
        suffix: str = "",
        rename_names: bool = False,
    ) -> tuple[str, str, int, int]:
        lexemes = self._lex_available(code)
        _prefix_code, prefix = self._code_with_sentinel(code, line, character)
        cursor_lexemes = self._lex_available(_prefix_code, "sentinel")
        if not cursor_lexemes:
            raise ValueError("No lexemes produced for completion query")

        cursor_lexeme_index = len(cursor_lexemes) - 1
        # The cursor boundary controls rendering, not which terminals are cached.
        if cursor_lexeme_index < len(lexemes):
            stable = lexemes[:cursor_lexeme_index]
            cursor_and_after = lexemes[cursor_lexeme_index:]
        else:
            stable = lexemes
            cursor_and_after = [cursor_lexemes[-1]]

        base_cursor, base_fed = self._advance_stable(stable)
        cursor = base_cursor.copy()  # Move independently; share cached parse states.
        fed = list(base_fed)
        cursor_index = -1
        for i, token in enumerate(cursor_and_after):
            before_len = len(fed)
            fed.extend(self._feed_one_available(token, cursor))
            if i == 0 and len(fed) > before_len:
                cursor_index = len(fed) - 1
        self.parser = cursor.parser

        if cursor_index < 0 or cursor_index >= len(fed):
            raise ValueError("Cursor token could not be fed to parser")
        if fed[cursor_index].type not in NAME_TERMINALS:
            raise ValueError("Cursor does not point at a name token")

        # Render incrementally: the stable prefix's rendered code (with rename
        # applied) is cached and reused across calls; only the cursor token + what
        # follows it + the grammar tail are rendered each call, continuing the
        # indent handshake from the stable prefix's end state.
        known = memory or set()
        if rename_names:
            stable_code, il, ic = self._render_stable(base_fed, known, suffix)
        else:
            stable_code, il, ic = self._render_from(base_fed, 0, False)

        extra = fed[len(base_fed):]
        ci = cursor_index - len(base_fed)
        extra_terms = []
        for j, token in enumerate(extra):
            if j == ci:
                extra_terms.append(Token(token.type, masker))
            elif rename_names and token.type in NAME_TERMINALS and str(token.value).strip() not in known:
                extra_terms.append(Token(token.type, str(token.value) + suffix))
            else:
                extra_terms.append(token)
        extra_code, il, ic = self._render_from(extra_terms, il, ic)
        head_code = stable_code + extra_code
        if head_code.count(masker) != 1:
            raise ValueError("Completion marker was not preserved exactly once")

        marker_index = head_code.find(masker)
        marker_prefix = head_code[:marker_index]
        marker_lines = marker_prefix.split("\n")
        marker_line = len(marker_lines) - 1
        marker_character = len(marker_lines[-1])

        # Render the tail continuing the head's indent state (rendering the tail
        # standalone would reset indent to 0 and underflow its _DEDENTs, emitting
        # closing clauses like `elif` at column 0).
        tail = self.complete_grammar()
        tail_code, _, _ = self._render_from(tail, il, ic)
        completed = head_code + tail_code
        return completed, prefix, marker_line, marker_character

    def _advance_stable(self, stable: list[Token]):
        """Reuse the last stable output prefix; the trie independently reuses parses."""
        if self._parser_trie_root is None:
            parser = self.lark.parse_interactive("")
            parser.parser_state.parse_conf.callbacks = {}
            self._parser_trie_root = {
                "parser": parser, "children": {},
            }
        keys = [(t.type, t.value) for t in stable]
        prev = self._inc
        if prev is not None and keys[:len(prev["keys"])] == prev["keys"]:
            cursor = prev["cursor"].copy()
            fed = list(prev["fed"])
            render = prev["render"]
            start = len(prev["keys"])
        else:
            cursor = _ParserTrieCursor(self._parser_trie_root)
            fed, render, start = [], None, 0
        for token in stable[start:]:
            fed.extend(self._feed_one_available(token, cursor))
        self._inc = {"cursor": cursor, "fed": fed, "keys": keys, "render": render}
        return cursor, fed

    def reset_incremental(self) -> None:
        """Drop all parser-prefix checkpoints and raw-lex baselines
        (e.g. on a new document)."""
        self._parser_trie_root = None
        self._inc = None
        self._raw_streams.clear()

    def name_candidates(self, code: str) -> set[str]:
        return {
            str(token.value).strip()
            for token in self._lex_available(code)
            if token.type in NAME_TERMINALS
        }

    def has_del(self, code: str) -> bool:
        """Whether ``code`` contains a ``del`` statement (a DEL keyword token).
        A ``del`` is the only thing that can remove a builtin/default name from
        scope, so callers use this to decide whether those names still need a
        pyflakes check. Reuses the incremental "plain" lex, so it is ~O(delta)."""
        return any(t.type == "DEL" for t in self._lex_available(code, "plain"))

    def _code_with_sentinel(self, code: str, line: int, character: int) -> tuple[str, str]:
        offset = _offset_from_position(code, line, character)
        prefix_start = offset
        while prefix_start > 0 and _is_identifier_char(code[prefix_start - 1]):
            prefix_start -= 1
        prefix = code[prefix_start:offset]
        return code[:offset] + SENTINEL, prefix

    def _lex_available(self, code: str, stream: str = "plain") -> list[Token]:
        try:
            lexemes = self._incremental_lex(code, stream)
        except lark.exceptions.UnexpectedCharacters as exc:
            # exc positions are full-code positions (the incremental path re-lexes
            # the whole code before it can raise); truncate at the bad char.
            self._raw_streams.pop(stream, None)
            lines = code.split("\n")
            usable = "\n".join(lines[: exc.line - 1] + [lines[exc.line - 1][: exc.column - 1]])
            lexemes = list(self.lark.lex(usable))

        while lexemes and lexemes[-1].type == "_DEDENT":
            lexemes.pop()
        return lexemes

    def _raw_lex(self, code: str) -> list[Token]:
        return list(LexerThread.from_text(self._raw_lexer, code).lex(None))

    @staticmethod
    def _offset_token(token: Token, off: int) -> Token:
        return Token(
            token.type, token.value,
            start_pos=(token.start_pos or 0) + off, line=token.line, column=token.column,
            end_line=token.end_line, end_column=token.end_column,
            end_pos=(token.end_pos or 0) + off,
        )

    def _postlex_run(self, tokens, state):
        """Run the indenter over ``tokens`` continuing from ``state`` (``None`` =
        fresh). Returns ``(output, new_state)`` with ``state`` =
        ``(indent_level, tmp_indent, tmp_newline)``, so the postlex can be resumed
        piecewise like the raw lex (its output for a stable prefix is reusable)."""
        ind = self._inc_indenter
        if state is None:
            ind.indent_level, ind.tmp_indent, ind.tmp_newline = [0], 0, None
        else:
            il, ti, tn = state
            ind.indent_level, ind.tmp_indent, ind.tmp_newline = list(il), ti, tn
        out = list(ind._process(iter(tokens)))
        return out, (list(ind.indent_level), ind.tmp_indent, ind.tmp_newline)

    def _incremental_lex(self, code: str, stream: str) -> list[Token]:
        """Full lexemes (raw lex + postlex) for ``code``, reusing a stream's cached
        raw tokens AND postlex output for the stable prefix -- only the appended
        delta is raw-lexed and postlexed. On any reuse miss / fresh document it
        rebuilds (may raise UnexpectedCharacters with full-code positions)."""
        prev = self._raw_streams.get(stream)
        delta = None
        if prev is not None and code.startswith(prev["kept_code"]):
            try:
                delta = [self._offset_token(t, prev["reuse_end"])
                         for t in self._raw_lex(code[prev["reuse_end"]:])]
            except lark.exceptions.UnexpectedCharacters:
                delta = None
        if delta:
            raw = prev["kept_raw"] + delta
            post_head, state, new_tokens = prev["post"], prev["state"], delta
        else:
            raw = self._raw_lex(code)
            post_head, state, new_tokens = [], None, raw

        # Postlex the newly-seen tokens continuing from the cached boundary state,
        # settling all but the last raw token (it can extend on append) into the
        # cache; the last token is postlexed transiently for this call's output.
        settle_toks, last_toks = new_tokens[:-1], new_tokens[-1:]
        mid_post, mid_state = self._postlex_run(settle_toks, state)
        last_post, _ = self._postlex_run(last_toks, mid_state)
        lexemes = post_head + mid_post + last_post

        if len(raw) >= 2:
            reuse_end = raw[-2].end_pos
            self._raw_streams[stream] = {
                "kept_code": code[:reuse_end], "kept_raw": raw[:-1], "reuse_end": reuse_end,
                "post": post_head + mid_post, "state": mid_state,
            }
        else:
            self._raw_streams.pop(stream, None)
        return lexemes

    def _feed_one_available(self, token: Token, parser) -> list[Token]:
        fed = []
        while True:
            try:
                parser.feed_token(token)
                fed.append(token)
                return fed
            except lark.exceptions.UnexpectedToken as exc:
                if exc.token.type == "_DEDENT":
                    return fed
                if len(exc.expected) != 1:
                    return fed
                expected = next(iter(exc.expected))
                if expected not in {"_INDENT", "_NEWLINE"}:
                    return fed
                synthetic = Token(expected, "\n" if expected == "_NEWLINE" else "")
                parser.feed_token(synthetic)
                fed.append(synthetic)

    def complete_grammar(self) -> list[str]:
        assert self.parser is not None
        # StateMapV2-based fill (DAG walk): always terminates, unlike the old
        # `_trace` while-loop which could spin forever on dead-end states.
        return fill_tail(self.parser.parser_state, fill_type="shortest", cache=self._state_map_cache)

    def terminals_to_code(self, terminals) -> str:
        return self._render_from(terminals, 0, False)[0]

    def _render_from(self, terminals, indent_level: int, indent_check: bool):
        # Indentation is emitted by a stateful handshake: a _NEWLINE/_INDENT/_DEDENT
        # marks the next token for indenting (indent_check), which then prepends
        # _INDENT * indent_level. That state must stay continuous across the whole
        # stream. Expanding nonterminals via recursion would restart it at indent 0,
        # so a newline ending one expansion and the token starting the next would be
        # rendered in separate passes -- severing the handshake and dropping the line
        # to column 0. Flattening first keeps one indent_level / indent_check pass.
        #
        # Returns (code, indent_level, indent_check) so a stream can be rendered in
        # pieces -- a cached stable prefix, then the delta / cursor / tail -- while
        # keeping the handshake continuous across the joins.
        parts = []
        for terminal_type, text in self._flatten_terminals(terminals):
            if terminal_type == "_INDENT":
                indent_check = True
                indent_level += 1
                continue
            if terminal_type == "_DEDENT":
                indent_check = True
                indent_level = max(0, indent_level - 1)
                continue
            if indent_check:
                parts.append(self.replace_table["_INDENT"] * indent_level)
                indent_check = False
            if terminal_type == "_NEWLINE":
                parts.append("\n")
                indent_check = True
                continue
            if not text:
                continue
            parts.append(text)
            if not text.endswith("\n"):
                parts.append(" ")
        return "".join(parts), indent_level, indent_check

    def _render_stable(self, base_fed, known, suffix):
        """Rendered code for the stable fed prefix with rename applied, reusing the
        cached render and rendering only the appended delta tokens. Returns
        (code, indent_level, indent_check). Cache is dropped when the rename
        parameters change (``known`` contents / ``suffix``)."""
        known = frozenset(known)
        r = self._inc.get("render")
        if r is None or r["known"] != known or r["suffix"] != suffix:
            r = {"code": "", "il": 0, "ic": False, "rn": 0, "known": known, "suffix": suffix}
        if r["rn"] < len(base_fed):
            renamed = [
                Token(t.type, str(t.value) + suffix)
                if (t.type in NAME_TERMINALS and str(t.value).strip() not in known)
                else t
                for t in base_fed[r["rn"]:]
            ]
            code, il, ic = self._render_from(renamed, r["il"], r["ic"])
            r = {"code": r["code"] + code, "il": il, "ic": ic,
                 "rn": len(base_fed), "known": known, "suffix": suffix}
        self._inc["render"] = r
        return r["code"], r["il"], r["ic"]

    def _flatten_terminals(self, terminals):
        """Expand nonterminal replacements into one flat (type, text) stream.

        Yields ``(marker, None)`` for ``_INDENT``/``_DEDENT``/``_NEWLINE`` and
        ``(type, stripped_text)`` for literal terminals. List replacements
        (nonterminal expansions) are flattened recursively so the caller renders a
        single continuous stream rather than restarting indent state per expansion.
        """
        for terminal in terminals:
            has_value = isinstance(terminal, Token)
            terminal_type = terminal.type if has_value else _symbol_name(terminal)
            if terminal_type in ("_INDENT", "_DEDENT", "_NEWLINE"):
                yield terminal_type, None
                continue
            replacement = terminal.value if has_value else self.replace_table[terminal_type]
            if isinstance(replacement, list):
                yield from self._flatten_terminals(replacement)
                continue
            yield terminal_type, str(replacement).strip()


def _is_identifier_char(char: str) -> bool:
    return char == "_" or char.isalnum()


def _offset_from_position(code: str, line: int, character: int) -> int:
    lines = code.splitlines(keepends=True)
    if line <= 0:
        return min(character, len(code))
    if line >= len(lines):
        return len(code)
    return min(sum(len(part) for part in lines[:line]) + character, len(code))
