from __future__ import annotations

import importlib
import keyword
import logging
import re
from dataclasses import dataclass
from typing import Any, Optional

_LOGGER = logging.getLogger("scopelens")


def _clear_parso_cache() -> None:
    # jedi/parso keeps a process-global parse cache that can go stale after
    # analyzing heavy C-extension packages (numpy), raising a KeyError on the
    # next query. Dropping it forces a clean re-parse.
    try:
        import parso

        parso.cache.parser_cache.clear()
    except Exception:
        pass


_ATTRIBUTE_CONTEXT_RE = re.compile(
    r"(?P<base>[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)\.(?P<prefix>[A-Za-z_]\w*)?$"
)


@dataclass(frozen=True)
class AttributeContext:
    base: str
    prefix: str
    line: int
    base_end_character: int


@dataclass(frozen=True)
class ModuleMemberCandidate:
    label: str
    detail: Optional[str] = None


class JediModuleMemberProvider:
    """Return members only when the attribute base resolves to a module."""

    def __init__(
        self,
        *,
        jedi_module: Optional[Any] = None,
        script_path: str = "scopelens_probe.py",
    ) -> None:
        self._jedi = jedi_module if jedi_module is not None else _load_jedi()
        self.script_path = script_path
        # Resolve imports against THIS server's own interpreter, where the
        # packages are actually installed. jedi otherwise picks an environment
        # from the inherited CONDA_PREFIX/VIRTUAL_ENV of the launching process
        # (e.g. gencor's run env), which may be missing packages the code imports
        # -- making a real module (e.g. python-docx's `docx`) look undefined.
        self._environment = None
        if self._jedi is not None:
            try:
                self._environment = self._jedi.InterpreterEnvironment()
            except Exception:
                self._environment = None
        # Per-module member cache: resolved module qualified name -> [(name, type)].
        # A module's members are static for this server's environment, so enumerate
        # once and reuse -- this skips jedi's ~37ms member `complete` on repeats. The
        # base is still re-resolved (cheap ~1ms goto) every query, so rebinding /
        # shadowing of the base name is caught. Bounded by the (small) number of
        # distinct modules seen.
        self._member_cache: dict[str, list[tuple[str, Optional[str]]]] = {}

    def _make_script(self, code: str) -> Any:
        if self._environment is not None:
            return self._jedi.Script(
                code, path=self.script_path, environment=self._environment
            )
        return self._jedi.Script(code, path=self.script_path)

    def complete(
        self,
        code: str,
        line: int,
        character: int,
    ) -> Optional[list[ModuleMemberCandidate]]:
        context = attribute_context_at(code, line, character)
        if context is None:
            return None
        if self._jedi is None:
            return []

        module_key = self._resolve_module_at(code, context.line, context.base_end_character)
        if module_key is None:            # base is not a module
            return []

        members = self._member_cache.get(module_key) if module_key else None
        if members is None:
            members = self._enumerate_members(code, context)
            if module_key:                # cache only a module with a stable name
                self._member_cache[module_key] = members

        return _candidates_from_members(members, context.prefix)

    def _resolve_module_at(self, code: str, line: int, character: int) -> Optional[str]:
        """Qualified name of the module the name at ``(line, character)`` resolves
        to, ``""`` if it is a module with no stable name, or ``None`` if it is not a
        module. ``line`` is 0-based. Same ``goto`` (and one stale-cache retry) as
        ``is_module_at``, but returns the identity used as the member-cache key --
        re-run every query so a rebinding/shadowing of the base is caught.
        """
        if self._jedi is None:
            return None
        for attempt in range(2):
            try:
                script = self._make_script(code)
                defs = script.goto(line + 1, character, follow_imports=True)
                for d in defs:
                    if getattr(d, "type", None) == "module":
                        return getattr(d, "full_name", None) or ""
                return None
            except Exception as exc:
                _LOGGER.warning("resolve_module goto failed (attempt %d): %r", attempt, exc)
                _clear_parso_cache()
        return None

    def _enumerate_members(self, code: str, context: AttributeContext) -> list[tuple[str, Optional[str]]]:
        """Full member set of the base module (unfiltered by prefix), as
        ``(name, type)`` pairs. Completed right after the base's dot so the result
        is prefix-independent and cacheable.
        """
        try:
            script = self._make_script(code)
            completions = script.complete(context.line + 1, context.base_end_character + 1)
        except Exception:
            return []
        members: list[tuple[str, Optional[str]]] = []
        for completion in completions:
            name = getattr(completion, "name", "")
            if isinstance(name, str) and name:
                members.append((name, getattr(completion, "type", None)))
        return members

    def is_module_at(self, code: str, line: int, character: int) -> bool:
        """Whether the name ending at ``(line, character)`` resolves to a module.

        Uses ``goto`` (definition resolution), not ``infer`` (value inference):
        ``infer`` is context-sensitive and reports a module referenced inside a
        list literal (e.g. ``[docx]``) as an ``instance``, whereas ``goto`` follows
        the name to its ``import`` and correctly reports ``module`` everywhere.
        ``line`` is 0-based.

        A jedi/parso stale-cache error (seen after analyzing numpy-backed code)
        is retried once on a fresh parse rather than silently answering "not a
        module", which would drop the module-member constraint.
        """
        if self._jedi is None:
            return False
        for attempt in range(2):
            try:
                script = self._make_script(code)
                defs = script.goto(line + 1, character, follow_imports=True)
                return any(getattr(d, "type", None) == "module" for d in defs)
            except Exception as exc:
                _LOGGER.warning("is_module_at goto failed (attempt %d): %r", attempt, exc)
                _clear_parso_cache()
        return False


def attribute_context_at(code: str, line: int, character: int) -> Optional[AttributeContext]:
    offset = _offset_from_position(code, line, character)
    line_start = code.rfind("\n", 0, offset) + 1
    line_prefix = code[line_start:offset]
    match = _ATTRIBUTE_CONTEXT_RE.search(line_prefix)
    if match is None:
        return None

    base = match.group("base")
    return AttributeContext(
        base=base,
        prefix=match.group("prefix") or "",
        line=line,
        base_end_character=match.start("base") + len(base),
    )


def _candidates_from_members(
    members: list[tuple[str, Optional[str]]],
    prefix: str,
) -> list[ModuleMemberCandidate]:
    candidates = []
    seen: set[str] = set()

    for label, member_type in members:
        if not isinstance(label, str) or not label:
            continue
        if label in seen:
            continue
        if prefix and not label.startswith(prefix):
            continue
        if not label.isidentifier() or keyword.iskeyword(label):
            continue

        seen.add(label)
        detail = "ScopeLens/Jedi module"
        if isinstance(member_type, str) and member_type:
            detail += " " + member_type
        candidates.append(ModuleMemberCandidate(label=label, detail=detail))

    return candidates


def _offset_from_position(code: str, line: int, character: int) -> int:
    lines = code.splitlines(keepends=True)
    if line <= 0:
        return min(character, len(code))
    if line >= len(lines):
        return len(code)
    return min(sum(len(part) for part in lines[:line]) + character, len(code))


def _load_jedi() -> Any | None:
    try:
        return importlib.import_module("jedi")
    except ImportError:
        return None
