#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib
import keyword
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence, Union

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
GENCOR = ROOT.parent / "gencor"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import lark
from lark.lexer import Token

from scopelens import analyzer
from scopelens.autocomplete import MASKER, NAME_TERMINALS, AutoCompleter
from scopelens.analyzer import CursorPosition, NameCandidate
from scopelens.member_provider import attribute_context_at


BOUND_TAG = "BOUND"
BOUND_TAG_ALIASES = {"CLOSED": BOUND_TAG}


@dataclass(frozen=True)
class CompletionTrace:
    completed_code: str
    head_code: str
    marker_line: int
    marker_character: int
    prefix: str
    fed: list[Token]
    cursor_index: int
    tail: list[str]


@dataclass(frozen=True)
class TaggedName:
    token: Token
    tags: set[str | None]


_tag_lark = None
_tag_parser = None


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Read incomplete Python code from stdin and show how ScopeLens "
            "turns the last NAME lexeme into a Pyflakes completion query."
        )
    )
    parser.add_argument(
        "--hide-builtins",
        action="store_true",
        help="Only show accepted names that came from the input code.",
    )
    args = parser.parse_args(argv)

    code = _read_stdin()
    if not code.strip():
        print("No code received on stdin.", file=sys.stderr)
        return 1

    end_position = _end_position(code)
    attribute_context = attribute_context_at(code, end_position.line, end_position.character)
    if attribute_context is not None:
        _print_module_member_probe(code, end_position)
        return 0

    completer = analyzer._get_autocompleter()
    tagged_name = _last_bound_name(code)
    if tagged_name is None:
        print("No NAME terminal whose possible tags include BOUND was found.", file=sys.stderr)
        return 1

    last_name = tagged_name.token
    position = _token_end_position(last_name)
    print("== Cursor ==")
    print(
        "last BOUND NAME %r at line %d, character %d (zero-based cursor: %d:%d)"
        % (
            str(last_name.value),
            getattr(last_name, "line", position.line + 1),
            getattr(last_name, "column", position.character + 1),
            position.line,
            position.character,
        )
    )
    print("possible tags: %s" % _format_tags(tagged_name.tags))
    print()

    trace = None
    try:
        trace = _completion_trace(
            completer,
            code,
            position,
            memory=analyzer.DEFAULT_NAMES,
            suffix=analyzer.NAME_SUFFIX,
            rename_names=True,
        )
        _print_tail_lexemes(completer, trace.tail)
        _print_code("Autocomplete suffix code", completer.terminals_to_code(trace.tail))
    except Exception as exc:
        print("== Autocomplete Lexemes ==")
        print("ScopeLens grammar autocomplete failed: %s" % exc)
        print("Pyflakes probe below may use analyzer fallback code.")
        print()

    print("== Available Names ==")
    try:
        names = _available_names(code, position)
        if args.hide_builtins:
            names = [name for name in names if name not in analyzer.DEFAULT_NAMES]
        print(_format_names(names))
    except Exception as exc:
        print("available_names failed: %s" % exc)
    print()

    print("== Pyflakes Probe ==")
    try:
        pyflakes_code, prefix, undefined = _pyflakes_probe(code, position)
        print("prefix at cursor: %r" % prefix)
        print("undefined names reported by Pyflakes: %s" % _format_names(sorted(undefined)))
        _print_code("Code passed to Pyflakes", pyflakes_code)
    except Exception as exc:
        print("Pyflakes probe construction failed: %s" % exc)

    if trace is not None:
        _print_code("Completed code before candidate injection", trace.completed_code)

    return 0


def _read_stdin() -> str:
    if sys.stdin.isatty():
        print("Paste incomplete Python code, then press Ctrl-D.")
    return sys.stdin.read()


def _end_position(code: str) -> CursorPosition:
    lines = code.split("\n")
    return CursorPosition(line=len(lines) - 1, character=len(lines[-1]))


def _print_module_member_probe(code: str, position: CursorPosition) -> None:
    context = attribute_context_at(code, position.line, position.character)
    if context is None:
        return

    print("== Cursor ==")
    print(
        "attribute access %r with prefix %r (zero-based cursor: %d:%d)"
        % (context.base, context.prefix, position.line, position.character)
    )
    print()

    print("== Module Members ==")
    print("jedi available: %s" % _yes_no(importlib.util.find_spec("jedi") is not None))
    print("base expression: %s" % context.base)
    print("prefix: %r" % context.prefix)
    try:
        candidates = list(analyzer.available_names(code, position))
        print(_format_candidates(candidates))
    except Exception as exc:
        print("module member probe failed: %s" % exc)
    print()


def _last_bound_name(code: str) -> TaggedName | None:
    try:
        names = _tagged_names(code)
    except Exception as exc:
        print("taglark NAME scan failed: %s" % exc, file=sys.stderr)
        return None

    for name in reversed(names):
        if BOUND_TAG in name.tags:
            return name
    return None


def _tagged_names(code: str) -> list[TaggedName]:
    parser = _get_tag_parser()
    tokens = _lex_available_with(parser, code)
    interactive = parser.parse_interactive("")
    fed_tokens = []
    name_indices: list[tuple[int, Token]] = []

    for token in tokens:
        fed = _feed_one_available(interactive, token)
        fed_tokens.extend(fed)
        if not fed or fed[-1] is not token:
            break
        if token.type == "NAME":
            name_indices.append((len(fed_tokens) - 1, token))

    tagged_names = []
    last_index = len(fed_tokens) - 1
    for index, token in name_indices:
        raw_tags = interactive.parser_state.get_nth_last_token_tag(last_index - index)
        tagged_names.append(TaggedName(token=token, tags=_normalize_tags(raw_tags)))

    return tagged_names


def _get_tag_parser() -> lark.Lark:
    global _tag_parser
    if _tag_parser is None:
        tag_lark = _get_tag_lark()
        grammar = (SRC / "scopelens" / "grammars" / "indent_python_tcf_grammar.lark").read_text(
            encoding="utf-8"
        )
        for old, new in BOUND_TAG_ALIASES.items():
            grammar = re.sub(r"@%s\b" % re.escape(old), "@%s" % new, grammar)
        _tag_parser = tag_lark.Lark(
            grammar,
            parser="lalr",
            start="start",
            postlex=_TagPythonIndenter(tag_lark),
            propagate_positions=True,
            keep_all_tokens=True,
            debug=False,
            taglark=True,
        )
    return _tag_parser


def _get_tag_lark():
    global _tag_lark
    if _tag_lark is not None:
        return _tag_lark
    if not GENCOR.exists():
        raise RuntimeError("Cannot find gencor vendored taglark at %s" % GENCOR)

    original_path = list(sys.path)
    original_lark_modules = {
        name: module
        for name, module in sys.modules.items()
        if name == "lark" or name.startswith("lark.")
    }
    for name in original_lark_modules:
        sys.modules.pop(name, None)

    sys.path.insert(0, str(GENCOR))
    try:
        _tag_lark = importlib.import_module("lark")
    finally:
        for name in list(sys.modules):
            if name == "lark" or name.startswith("lark."):
                sys.modules.pop(name, None)
        sys.modules.update(original_lark_modules)
        sys.path[:] = original_path

    return _tag_lark


class _TagPythonIndenter:
    NL_type = "_NEWLINE"
    COMMENT_type = "COMMENT"
    INDENT_type = "_INDENT"
    DEDENT_type = "_DEDENT"
    always_accept = ()
    tab_len = 4

    def __init__(self, tag_lark_module) -> None:
        self._token = tag_lark_module.Token
        self.indent_level = [0]
        self.tmp_indent = 0
        self.tmp_newline = None

    def process(self, stream):
        self.indent_level = [0]
        self.tmp_indent = 0
        self.tmp_newline = None
        return self._process(stream)

    def _process(self, stream):
        for token in stream:
            if token.type == self.NL_type:
                self._handle_newline(token)
            elif token.type == self.COMMENT_type:
                if self.tmp_newline is not None:
                    yield self.tmp_newline
                    self.tmp_newline = None
                yield token
            else:
                if self.tmp_newline is not None:
                    yield self.tmp_newline
                    self.tmp_newline = None
                yield from self._handle_non_newline(token)

    def _handle_newline(self, token) -> None:
        try:
            indent_str = token.value.rsplit("\n", 1)[1]
        except IndexError:
            indent_str = ""
        self.tmp_indent = indent_str.count(" ") + indent_str.count("\t") * self.tab_len
        self.tmp_newline = token

    def _handle_non_newline(self, token):
        indent = self.tmp_indent
        if indent > self.indent_level[-1]:
            self.indent_level.append(indent)
            yield self._token(self.INDENT_type, " " * indent)
        else:
            while indent < self.indent_level[-1]:
                self.indent_level.pop()
                yield self._token(self.DEDENT_type, " " * indent)

            if indent != self.indent_level[-1]:
                raise RuntimeError(
                    "Unexpected dedent to column %s. Expected dedent to %s"
                    % (indent, self.indent_level[-1])
                )

        yield token


def _lex_available_with(parser, code: str) -> list[Token]:
    tag_lark = _get_tag_lark()
    try:
        tokens = list(parser.lex(code))
    except tag_lark.exceptions.UnexpectedCharacters as exc:
        lines = code.split("\n")
        usable = "\n".join(lines[: exc.line - 1] + [lines[exc.line - 1][: exc.column - 1]])
        tokens = list(parser.lex(usable))

    while tokens and tokens[-1].type == "_DEDENT":
        tokens.pop()
    return tokens


def _feed_one_available(interactive, token: Token) -> list[Token]:
    tag_lark = _get_tag_lark()
    fed = []
    while True:
        try:
            interactive.feed_token(token)
            fed.append(token)
            return fed
        except tag_lark.exceptions.UnexpectedToken as exc:
            if exc.token.type == "_DEDENT":
                return fed
            if len(exc.expected) != 1:
                return fed
            expected = next(iter(exc.expected))
            if expected not in {"_INDENT", "_NEWLINE"}:
                return fed
            synthetic = tag_lark.Token(expected, "\n" if expected == "_NEWLINE" else "")
            interactive.feed_token(synthetic)
            fed.append(synthetic)


def _normalize_tags(tags: Iterable[str | None]) -> set[str | None]:
    return {BOUND_TAG_ALIASES.get(tag, tag) for tag in tags}


def _format_tags(tags: Iterable[str | None]) -> str:
    labels = sorted("None" if tag is None else str(tag) for tag in tags)
    return "{" + ", ".join(labels) + "}"


def _token_end_position(token: Token) -> CursorPosition:
    end_line = getattr(token, "end_line", None)
    end_column = getattr(token, "end_column", None)
    if end_line is not None and end_column is not None:
        return CursorPosition(line=end_line - 1, character=end_column - 1)

    line = getattr(token, "line", 1)
    column = getattr(token, "column", 1)
    return CursorPosition(line=line - 1, character=column - 1 + len(str(token.value)))


def _completion_trace(
    completer: AutoCompleter,
    code: str,
    position: CursorPosition,
    masker: str = MASKER,
    memory: set[str] | None = None,
    suffix: str = "",
    rename_names: bool = False,
) -> CompletionTrace:
    lexemes = completer._lex_available(code)
    prefix_code, prefix = completer._code_with_sentinel(
        code,
        position.line,
        position.character,
    )
    cursor_lexemes = completer._lex_available(prefix_code)
    if not lexemes or not cursor_lexemes:
        raise ValueError("No lexemes produced for completion query")

    completer.parser = completer.lark.parse_interactive("")
    fed: list[Token] = []
    cursor_index = -1
    cursor_lexeme_index = len(cursor_lexemes) - 1
    for index, token in enumerate(lexemes):
        before_len = len(fed)
        fed.extend(completer._feed_one_available(token))
        if index == cursor_lexeme_index and len(fed) > before_len:
            cursor_index = len(fed) - 1

    if cursor_index < 0 or cursor_index >= len(fed):
        raise ValueError("Cursor token could not be fed to parser")
    if fed[cursor_index].type not in NAME_TERMINALS:
        raise ValueError("Cursor does not point at a name token")

    if rename_names:
        known = memory or set()
        for index, token in enumerate(fed):
            if index == cursor_index:
                continue
            if token.type in NAME_TERMINALS and str(token.value).strip() not in known:
                fed[index] = Token(token.type, str(token.value) + suffix)

    fed[cursor_index] = Token(fed[cursor_index].type, masker)

    head_code = completer.terminals_to_code(fed)
    if head_code.count(masker) != 1:
        raise ValueError("Completion marker was not preserved exactly once")

    marker_index = head_code.find(masker)
    marker_prefix = head_code[:marker_index]
    marker_lines = marker_prefix.split("\n")
    marker_line = len(marker_lines) - 1
    marker_character = len(marker_lines[-1])

    tail = completer.complete_grammar()
    completed_code = head_code + completer.terminals_to_code(tail)
    return CompletionTrace(
        completed_code=completed_code,
        head_code=head_code,
        marker_line=marker_line,
        marker_character=marker_character,
        prefix=prefix,
        fed=fed,
        cursor_index=cursor_index,
        tail=tail,
    )


def _print_tail_lexemes(completer: AutoCompleter, tail: Sequence[str]) -> None:
    print("== Autocomplete Lexemes ==")
    if not tail:
        print("(none)")
        print()
        return

    for index, lexeme in enumerate(tail, start=1):
        print("%02d. %s -> %s" % (index, lexeme, _terminal_value_repr(completer, lexeme)))
    print()


def _terminal_value_repr(completer: AutoCompleter, lexeme: str) -> str:
    try:
        value = completer.replace_table[lexeme]
    except Exception as exc:
        return "<unmapped: %s>" % exc
    if isinstance(value, list):
        return repr(completer.terminals_to_code(value))
    return repr(value)


def _available_names(code: str, position: CursorPosition) -> list[str]:
    names = []
    for candidate in analyzer.available_names(code, position):
        if isinstance(candidate, NameCandidate):
            names.append(candidate.label)
        else:
            names.append(str(candidate))
    return sorted(set(names))


def _pyflakes_probe(code: str, position: CursorPosition) -> tuple[str, str, set[str]]:
    prefix_code, prefix, renamed_names = analyzer._complete_code(code, position)
    candidates = analyzer._candidate_pool(code, uri=None)

    dynamic_names = {
        name
        for name in candidates
        if name.isidentifier()
        and not keyword.iskeyword(name)
        and name not in analyzer.DEFAULT_NAMES
    }
    memory = set(analyzer.DEFAULT_NAMES)
    if renamed_names:
        memory.update(name + analyzer.NAME_SUFFIX for name in dynamic_names)
    else:
        memory.update(dynamic_names)

    pyflakes_code = analyzer._inject_candidates(prefix_code, memory)
    return pyflakes_code, prefix, analyzer._undefined_names(pyflakes_code)


def _format_names(names: Iterable[str]) -> str:
    names = list(names)
    if not names:
        return "(none)"
    return ", ".join(names)


def _format_candidates(candidates: Iterable[Union[str, NameCandidate]]) -> str:
    rows = []
    for candidate in candidates:
        if isinstance(candidate, NameCandidate):
            if candidate.detail:
                rows.append("%s (%s)" % (candidate.label, candidate.detail))
            else:
                rows.append(candidate.label)
        else:
            rows.append(str(candidate))

    return _format_names(sorted(set(rows)))


def _yes_no(value: bool) -> str:
    return "yes" if value else "no"


def _print_code(title: str, code: str) -> None:
    print("== %s ==" % title)
    print("```python")
    print(code.rstrip("\n"))
    print("```")
    print()


if __name__ == "__main__":
    raise SystemExit(main())
