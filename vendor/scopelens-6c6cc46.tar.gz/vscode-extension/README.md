# ScopeLens VS Code Extension

Local VS Code client wrapper for the ScopeLens Python language server.

## Local Install

From this directory:

```bash
npm install
./scripts/install-local.sh
```

The install script links the extension into the current VS Code extension
directory. In a Remote SSH / server session it uses:

```text
$VSCODE_AGENT_FOLDER/extensions
```

Otherwise it uses:

```text
~/.vscode/extensions
```

Then reload VS Code and open a Python file. The extension auto-detects:

```text
~/miniconda3/envs/scopelens/bin/python
```

It also adds the adjacent ScopeLens `../src` directory to `PYTHONPATH`, so the
server runs from this checkout without needing a wheel build.

## Settings

- `scopelens.pythonPath`: Python executable used to run the server.
- `scopelens.serverSourcePath`: ScopeLens `src` directory. Empty uses `../src`.
- `scopelens.logLevel`: Server log level.
- `scopelens.extraArgs`: Extra arguments passed to the server.

## Development Host

Open this `vscode-extension` folder in VS Code and press F5. The launched
Extension Development Host will run the wrapper from source.
