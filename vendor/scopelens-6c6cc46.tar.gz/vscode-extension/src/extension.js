const fs = require("fs");
const os = require("os");
const path = require("path");
const vscode = require("vscode");
const { LanguageClient } = require("vscode-languageclient/node");

let client;
let outputChannel;
let restartTimer;

async function activate(context) {
  outputChannel = vscode.window.createOutputChannel("ScopeLens");
  context.subscriptions.push(outputChannel);

  context.subscriptions.push(
    vscode.commands.registerCommand("scopelens.restartServer", async () => {
      await restartClient(context);
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("scopelens.showOutput", () => {
      outputChannel.show(true);
    })
  );

  context.subscriptions.push(
    vscode.workspace.onDidChangeConfiguration((event) => {
      if (event.affectsConfiguration("scopelens")) {
        scheduleRestart(context);
      }
    })
  );

  context.subscriptions.push({
    dispose: () => {
      void stopClient();
    },
  });

  await startClient(context);
}

async function deactivate() {
  if (restartTimer) {
    clearTimeout(restartTimer);
    restartTimer = undefined;
  }
  await stopClient();
}

function scheduleRestart(context) {
  if (restartTimer) {
    clearTimeout(restartTimer);
  }

  restartTimer = setTimeout(() => {
    restartTimer = undefined;
    void restartClient(context);
  }, 250);
}

async function restartClient(context) {
  await stopClient();
  await startClient(context);
}

async function startClient(context) {
  const config = vscode.workspace.getConfiguration("scopelens");
  if (!config.get("enabled", true)) {
    outputChannel.appendLine("[ScopeLens] Disabled by configuration.");
    return;
  }

  const pythonPath = resolvePythonPath(config);
  const serverSourcePath = resolveServerSourcePath(context, config);
  const logLevel = config.get("logLevel", "WARNING");
  const extraArgs = config.get("extraArgs", []);
  const args = ["-m", "scopelens.server", "--log-level", logLevel, ...extraArgs];
  const cwd = serverSourcePath ? path.dirname(serverSourcePath) : realExtensionPath(context);
  const env = buildServerEnv(serverSourcePath);

  outputChannel.appendLine(`[ScopeLens] Starting server: ${pythonPath} ${args.join(" ")}`);
  if (serverSourcePath) {
    outputChannel.appendLine(`[ScopeLens] Using source path: ${serverSourcePath}`);
  } else {
    outputChannel.appendLine("[ScopeLens] No local source path found; relying on installed Python package.");
  }

  const executable = {
    command: pythonPath,
    args,
    options: {
      cwd,
      env,
    },
  };

  client = new LanguageClient(
    "scopelens",
    "ScopeLens",
    {
      run: executable,
      debug: executable,
    },
    {
      documentSelector: [
        { scheme: "file", language: "python" },
        { scheme: "untitled", language: "python" },
      ],
      outputChannel,
      initializationOptions: {
        serverSourcePath: serverSourcePath || null,
      },
    }
  );

  try {
    await client.start();
    outputChannel.appendLine("[ScopeLens] Language client started.");
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    outputChannel.appendLine(`[ScopeLens] Failed to start: ${message}`);
    const choice = await vscode.window.showErrorMessage(
      `ScopeLens failed to start: ${message}`,
      "Show Output",
      "Open Settings"
    );
    if (choice === "Show Output") {
      outputChannel.show(true);
    } else if (choice === "Open Settings") {
      await vscode.commands.executeCommand("workbench.action.openSettings", "scopelens");
    }
  }
}

async function stopClient() {
  const current = client;
  client = undefined;
  if (current) {
    await current.stop();
    outputChannel?.appendLine("[ScopeLens] Language client stopped.");
  }
}

function resolvePythonPath(config) {
  const configured = expandPath(config.get("pythonPath", ""));
  if (configured) {
    return configured;
  }

  const envPython = expandPath(process.env.SCOPELENS_PYTHON || "");
  if (envPython) {
    return envPython;
  }

  for (const candidate of pythonPathCandidates()) {
    if (path.isAbsolute(candidate) && fs.existsSync(candidate)) {
      return candidate;
    }
  }

  return process.platform === "win32" ? "python" : "python3";
}

function pythonPathCandidates() {
  const home = os.homedir();
  const executable = process.platform === "win32" ? "python.exe" : "python";
  const condaRoots = ["miniconda3", "anaconda3", "mambaforge", "miniforge3"];

  return condaRoots.map((root) =>
    path.join(home, root, "envs", "scopelens", process.platform === "win32" ? "" : "bin", executable)
  );
}

function resolveServerSourcePath(context, config) {
  const configured = expandPath(config.get("serverSourcePath", ""));
  if (configured) {
    return configured;
  }

  const extensionPaths = unique([context.extensionPath, realExtensionPath(context)]);
  const candidates = [];
  for (const extensionPath of extensionPaths) {
    candidates.push(path.resolve(extensionPath, "..", "src"));
    candidates.push(path.resolve(extensionPath, "server", "src"));
  }

  for (const candidate of unique(candidates)) {
    if (fs.existsSync(path.join(candidate, "scopelens", "server.py"))) {
      return candidate;
    }
  }

  return undefined;
}

function buildServerEnv(serverSourcePath) {
  const env = {
    ...process.env,
    PYTHONUNBUFFERED: "1",
  };

  if (serverSourcePath) {
    env.PYTHONPATH = [serverSourcePath, env.PYTHONPATH].filter(Boolean).join(path.delimiter);
  }

  return env;
}

function realExtensionPath(context) {
  try {
    return fs.realpathSync.native(context.extensionPath);
  } catch (_error) {
    return context.extensionPath;
  }
}

function expandPath(value) {
  if (!value || typeof value !== "string") {
    return "";
  }

  let expanded = value.trim();
  if (!expanded) {
    return "";
  }

  if (expanded === "~" || expanded.startsWith(`~${path.sep}`)) {
    expanded = path.join(os.homedir(), expanded.slice(2));
  }

  const firstWorkspace = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath || "";
  return expanded.replace(/\$\{workspaceFolder\}/g, firstWorkspace);
}

function unique(values) {
  return [...new Set(values.filter(Boolean))];
}

module.exports = {
  activate,
  deactivate,
};
