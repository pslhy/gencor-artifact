#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

npm install

if [ -n "${VSCODE_EXTENSIONS:-}" ]; then
  extensions_dir="$VSCODE_EXTENSIONS"
elif [ -n "${VSCODE_AGENT_FOLDER:-}" ]; then
  extensions_dir="$VSCODE_AGENT_FOLDER/extensions"
else
  extensions_dir="$HOME/.vscode/extensions"
fi
target="$extensions_dir/scopelens-vscode-local"

mkdir -p "$extensions_dir"

if [ -e "$target" ] && [ ! -L "$target" ]; then
  echo "Refusing to overwrite non-symlink path: $target" >&2
  exit 1
fi

ln -sfn "$PWD" "$target"

echo "Linked ScopeLens extension:"
echo "  $target -> $PWD"
echo
echo "Reload VS Code, then run 'ScopeLens: Show Output' if you want to inspect startup logs."
