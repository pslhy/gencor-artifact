# ScopeLens

ScopeLens is a completion-only Python language server for names visible at a
cursor position in incomplete Python code.

The analyzer uses the same broad strategy as gencor's Pyflakes integration:

1. Use a Lark-based autocompleter to synthesize enough dummy Python code around
   an incomplete cursor position.
2. Replace the cursor name with a batch of candidate names.
3. Run Pyflakes and keep candidates that are not reported as undefined.

The public analyzer entry point is:

```python
# src/scopelens/analyzer.py
def available_names(code, position, *, uri=None):
    ...
```

## Install

```bash
pip install -e .
```

## Run

Most editors start language servers over stdio:

```bash
scopelens
```

For manual testing, TCP mode is also available:

```bash
scopelens --tcp --host 127.0.0.1 --port 2087
```

The playground can inspect both bare-name completion and module-member
completion. Module-member probes use Jedi when the cursor is after an attribute
access:

```bash
printf 'import os\nos.pa' | PYTHONPATH=src python playground.py
```

## Analyzer Contract

`available_names` receives:

- `code`: full document text
- `position`: zero-based LSP cursor position
- `uri`: document URI, if available

It may return strings or `NameCandidate` objects:

```python
from scopelens.analyzer import NameCandidate

return [
    "tokens",
    NameCandidate("text", detail="local variable"),
]
```

The analyzer module also exposes document lifecycle hooks used to refresh the
per-document candidate cache:

```python
def did_open(document): ...
def did_change(document): ...
def did_save(document, text=None): ...
def did_close(uri): ...
```

`document` is a `DocumentSnapshot` with `uri`, `source`, `language_id`, and
`version`.
